# English-Persian-Word-Database
English Persian Word Database - Popular database extensions

* Author: Amir Shokri
* Author Email: amirsh.nll@gmail.com
* Last Update: 1 january, 2021
* Data format: JSON, SQL, XLSX, MDB Data
* Contribute: Fork and Push Requests :)
* DOI : 10.34740/kaggle/dsv/2528305
